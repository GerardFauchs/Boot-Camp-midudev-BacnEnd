export default {
  TOGGABLE: {
    CANCEL_BUTTON: 'Exit'
  }
}